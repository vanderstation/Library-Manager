/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classIcons;

import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * Este es una Clase para agregar los iconos en las esquina de las ventanas
 */
public class LibraryAssistanUtil {
    public static final String IMAGE_LOC = "/classIcons/contact.png";
    
    public static void setStageIcon(Stage stage){
        stage.getIcons().add(new Image(IMAGE_LOC));
        
    }
}
