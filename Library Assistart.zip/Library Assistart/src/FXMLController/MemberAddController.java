/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXMLController;

import LibraryDatabase.DatabaseHandler;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MemberAddController implements Initializable {

    DatabaseHandler handel;
    @FXML
    private JFXTextField name;
    @FXML
    private JFXTextField id;
    @FXML
    private JFXTextField mobile;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXButton saveButton;
    @FXML
    private JFXButton cancelButton;
    @FXML
    private AnchorPane rootPane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        handel = DatabaseHandler.getInstance();
    }

    @FXML
    private void cancelBook(ActionEvent event) {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.close();
    }

    @FXML
   public void addMember(ActionEvent event) {
		
		String mname = name.getText();
		String mid = id.getText();
		String mmobile = mobile.getText();
		String memail = email.getText();
		
		if(mname.isEmpty()||mid.isEmpty()||mmobile.isEmpty()||memail.isEmpty()){
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setContentText("please fill all the fields.");
			alert.showAndWait();
			return;
		}
        String st = "INSERT INTO public.member(id, name, mobile, email) VALUES ("
                + "'" + mid + "',"
                + "'" + mname + "',"
                + "'" + mmobile + "',"
                + "'" + memail + "'"
                + ")";
        System.out.println(st);
        if(handel.execAction(st)){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Saved");
            alert.showAndWait();
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Error Occured");
            alert.showAndWait();
        }

    }

}
