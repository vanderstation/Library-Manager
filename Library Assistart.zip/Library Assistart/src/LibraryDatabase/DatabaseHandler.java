/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LibraryDatabase;

import FXMLController.BookListController;
import FXMLController.BookListController.Book;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author localhost
 */
public final class DatabaseHandler {

    private static DatabaseHandler handler = null;
    private static Connection conn = null;
    private static Statement stmt = null;

    private DatabaseHandler() {
        createConnection();
        setupBookTable();

    }

    public static DatabaseHandler getInstance() {

        if (handler == null) {

            handler = new DatabaseHandler();
        }

        return handler;
    }

    void createConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/libraryBook", "pedro", "root1234");
            System.out.println("Opened database successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void setupBookTable() {

        String TABLE_NAME = "BOOK";

        try {
            stmt = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);

            if (tables.next()) {
                System.out.println("Table" + TABLE_NAME + "already. Ready for go!!!!");
            } else {
                System.out.println(" Ready for go!!!!");
            }

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    public ResultSet execQuery(String query) {
        ResultSet result;

        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(query);
        } catch (SQLException ex) {
            System.out.println("Exception at execQuery:dataHandler" + ex.getLocalizedMessage());
            return null;
        } finally {
        }
        return result;
    }

    public boolean execAction(String qu) {
        try {
            stmt = conn.createStatement();
            stmt.execute(qu);
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {

        }
    }

    public boolean delecteBook(Book book) {
        try {
            String deleteStatement = "DELETE FROM book WHERE id = ? ";
            PreparedStatement stmt = conn.prepareStatement(deleteStatement);
            stmt.setString(1, book.getId());
            int res = stmt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookListController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean isBookAlreadyIssued(Book book){
        try {
            String checkstmt = "SELECT COUNT(*) FROM issue WHERE bookid = ? ";
            PreparedStatement stmt = conn.prepareStatement(checkstmt);
            stmt.setString(1, book.getId());
            ResultSet rs =stmt.executeQuery();
            if(rs.next()){
                int count = rs.getInt(1);
                System.out.println(count);
                return(count > 0);
                
            }
            int res = stmt.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookListController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
